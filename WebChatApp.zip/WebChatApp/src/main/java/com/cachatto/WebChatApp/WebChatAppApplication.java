package com.cachatto.WebChatApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebChatAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebChatAppApplication.class, args);
	}

}
