package com.cachatto.WebChatApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebChatAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
